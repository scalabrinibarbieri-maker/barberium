import { criarCliente } from '../shared/api.js?v=1';

/* Barberium v12.47 · apresentação + modo manutenção da Área do Cliente */
(() => {
  const $=(s,r=document)=>r.querySelector(s);
  const esc=(v='')=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));

  // Login e chamadas ao banco: shared/api.js (etapa 5).
  const api=criarCliente();
  const rpc=(name,payload={})=>api.rpc(name,payload);
  function toast(msg){const t=$('#toast');if(!t)return;t.textContent=msg;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),3000)}
  function defaults(st={}){
    return {
      kicker:st.client_services_kicker||'Experiências',
      title:st.client_services_title||'Nossos serviços',
      intro:st.client_services_intro||'Trabalhamos com uma seleção premium de atendimentos para manter sua experiência mais prática e elegante. Ao tocar em Agendar agora, você verá todos os serviços disponíveis com seus respectivos valores e duração.',
      bullets:Array.isArray(st.client_services_bullets)?st.client_services_bullets.join('\n'):(st.client_services_bullets||'Cortes, barba tradicional e barba express\nCombos completos com barba, sobrancelha e barboterapia\nBarboterapia, sobrancelha, pezinho detalhes e cabeça raspada'),
      cta:st.client_services_cta||'Ver serviços e agendar →',
      maintenance:st.client_maintenance_mode==null?true:st.client_maintenance_mode===true,
      maintenanceMessage:st.client_maintenance_message||'Estamos realizando uma atualização. Os agendamentos online voltarão em breve.'
    };
  }

  async function enhance(){
    const form=$('#v1224ClientAppearance');
    if(!form||form.dataset.v1228Presentation==='1')return;
    form.dataset.v1228Presentation='1';

    try{
      const boot=await rpc('barberium_staff_settings_bootstrap');
      const unitId=$('#settingsUnitSelect')?.value;
      const unit=(boot.units||[]).find(u=>u.id===unitId);
      if(!unit)return;
      const d=defaults(unit.settings||{});
      const media=form.querySelector('.v1224-media-grid');
      if(!media)return;
      const block=document.createElement('div');
      block.id='v1228PresentationFields';
      block.innerHTML=`
        <h3 class="settings-section-title">Disponibilidade da Área do Cliente</h3>
        <p class="settings-hint">Use esta opção para interromper temporariamente o acesso dos clientes sem afetar a Área da Equipe.</p>
        <label class="permission-item">
          <span><strong>Modo manutenção da Área do Cliente</strong><small>Quando ligado, clientes não conseguem acessar o agendamento, perfil ou horários.</small></span>
          <input id="v1247MaintenanceMode" type="checkbox" ${d.maintenance?'checked':''}>
        </label>
        <div class="field">
          <label>Mensagem durante a manutenção</label>
          <textarea id="v1247MaintenanceMessage" rows="3" placeholder="Ex.: Voltaremos em breve.">${esc(d.maintenanceMessage)}</textarea>
          <small class="v1224-helper">Se houver WhatsApp cadastrado na unidade, o cliente verá um botão para falar com a barbearia.</small>
        </div>

        <h3 class="settings-section-title">Apresentação da página inicial</h3>
        <p class="settings-hint">Personalize o bloco que apresenta os serviços ao cliente. Em “Destaques”, use uma linha para cada item.</p>
        <div class="settings-two">
          <div class="field"><label>Chamada da seção</label><input id="v1228ServicesKicker" value="${esc(d.kicker)}" placeholder="Ex.: Experiências"></div>
          <div class="field"><label>Título da seção</label><input id="v1228ServicesTitle" value="${esc(d.title)}" placeholder="Ex.: Nossos serviços"></div>
        </div>
        <div class="field"><label>Texto de apresentação</label><textarea id="v1228ServicesIntro" rows="5" placeholder="Conte ao cliente como é a experiência da barbearia.">${esc(d.intro)}</textarea></div>
        <div class="field"><label>Destaques</label><textarea id="v1228ServicesBullets" rows="5" placeholder="Uma linha por destaque">${esc(d.bullets)}</textarea><small class="v1224-helper">Deixe vazio se não quiser mostrar a lista.</small></div>
        <div class="field"><label>Texto do botão</label><input id="v1228ServicesCta" value="${esc(d.cta)}" placeholder="Ex.: Ver serviços e agendar →"></div>`;
      form.insertBefore(block,media);

      form.onsubmit=async event=>{
        event.preventDefault();
        if(form.dataset.uploading==='1'){toast('Aguarde o envio da imagem terminar.');return;}
        const button=form.querySelector('[type=submit]');
        button.disabled=true;button.textContent='Salvando…';
        try{
          const fresh=await rpc('barberium_staff_settings_bootstrap');
          const id=$('#settingsUnitSelect')?.value;
          const u=(fresh.units||[]).find(x=>x.id===id);
          if(!u)throw new Error('Unidade não encontrada.');
          const bullets=$('#v1228ServicesBullets',form).value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
          const merged={...(u.settings||{}),
            client_header_subtitle:$('#v1224HeaderSubtitle',form).value.trim(),
            client_hero_label:$('#v1224HeroLabel',form).value.trim(),
            client_hero_title:$('#v1224HeroTitle',form).value.trim()||'Agende seu horário.',
            client_logo_url:$('#v1224LogoUrl',form).value.trim(),
            client_hero_image_url:$('#v1224HeroUrl',form).value.trim(),
            client_services_kicker:$('#v1228ServicesKicker',form).value.trim()||'Experiências',
            client_services_title:$('#v1228ServicesTitle',form).value.trim()||'Nossos serviços',
            client_services_intro:$('#v1228ServicesIntro',form).value.trim(),
            client_services_bullets:bullets,
            client_services_cta:$('#v1228ServicesCta',form).value.trim()||'Ver serviços e agendar →',
            client_maintenance_mode:$('#v1247MaintenanceMode',form).checked,
            client_maintenance_message:$('#v1247MaintenanceMessage',form).value.trim()||'Estamos realizando uma atualização. Os agendamentos online voltarão em breve.'
          };
          await rpc('barberium_staff_save_unit',{
            p_unit_id:u.id,p_name:u.name,p_city:u.city||null,p_state:u.state||null,p_whatsapp:u.whatsapp||null,p_maps_url:u.maps_url||null,p_is_active:u.is_active!==false,p_settings:merged
          });
          toast('Personalização salva.');button.textContent='Salvo ✓';
          setTimeout(()=>{if(form.isConnected){button.disabled=false;button.textContent='Salvar personalização'}},1400);
        }catch(err){toast(err?.message||'Não foi possível salvar.');button.disabled=false;button.textContent='Salvar personalização';}
      };
    }catch(err){console.error('Barberium v12.28 apresentação:',err)}
  }

  const observer=new MutationObserver(()=>setTimeout(enhance,0));
  observer.observe(document.documentElement,{childList:true,subtree:true});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(enhance,200),{once:true});
  else setTimeout(enhance,200);
  setTimeout(enhance,800);setTimeout(enhance,1600);
})();


/* Barberium v12.29 · correção cirúrgica de "Minhas comissões" para barbeiros.
   Bypassa a cadeia de interceptadores de fetch apenas nesta RPC.
   Nenhuma outra chamada da Área da Equipe é alterada. */
(() => {
  const previousFetch=window.fetch.bind(window);
  const TARGET=/\/rest\/v1\/rpc\/barberium_staff_my_commissions(?:\?|$)/;

  function headersObject(headers){
    if(!headers)return {};
    if(headers instanceof Headers)return Object.fromEntries(headers.entries());
    if(Array.isArray(headers))return Object.fromEntries(headers);
    return {...headers};
  }

  function xhrResponse(url,init={}){
    return new Promise((resolve,reject)=>{
      const xhr=new XMLHttpRequest();
      xhr.open(init.method||'GET',url,true);
      xhr.timeout=12000;

      for(const [key,value] of Object.entries(headersObject(init.headers))){
        if(value!=null)xhr.setRequestHeader(key,String(value));
      }

      if(init.signal){
        if(init.signal.aborted){xhr.abort();reject(new DOMException('Abortado','AbortError'));return}
        init.signal.addEventListener('abort',()=>xhr.abort(),{once:true});
      }

      xhr.onload=()=>{
        const responseHeaders=new Headers();
        const raw=xhr.getAllResponseHeaders().trim();
        if(raw){
          for(const line of raw.split(/[\r\n]+/)){
            const i=line.indexOf(':');
            if(i>0)responseHeaders.append(line.slice(0,i).trim(),line.slice(i+1).trim());
          }
        }
        resolve(new Response(xhr.responseText,{
          status:xhr.status,
          statusText:xhr.statusText,
          headers:responseHeaders
        }));
      };
      xhr.onerror=()=>reject(new TypeError('Falha de conexão ao carregar suas comissões.'));
      xhr.ontimeout=()=>reject(new Error('A conexão demorou mais que o esperado. Tente novamente.'));
      xhr.onabort=()=>reject(new DOMException('Abortado','AbortError'));

      xhr.send(init.body??null);
    });
  }

  window.fetch=function(input,init={}){
    const url=typeof input==='string'?input:input?.url;
    if(typeof url==='string'&&TARGET.test(url)){
      return xhrResponse(url,init);
    }
    return previousFetch(input,init);
  };
})();


/* Barberium v12.42 · correção do salvamento da aparência pública
   Evita que a proteção antiga de settings substitua logo/capa/títulos novos
   pelos valores anteriores ao salvar a personalização da Área do Cliente. */
(() => {
  const previousFetch=window.fetch.bind(window);
  const TARGET=/\/rest\/v1\/rpc\/barberium_staff_save_unit(?:\?|$)/;
  const $=(s,r=document)=>r.querySelector(s);

  function headersObject(headers){
    if(!headers)return {};
    if(headers instanceof Headers)return Object.fromEntries(headers.entries());
    if(Array.isArray(headers))return Object.fromEntries(headers);
    return {...headers};
  }

  function xhrResponse(url,init={}){
    return new Promise((resolve,reject)=>{
      const xhr=new XMLHttpRequest();
      xhr.open(init.method||'POST',url,true);
      xhr.timeout=15000;

      for(const [key,value] of Object.entries(headersObject(init.headers))){
        if(value!=null)xhr.setRequestHeader(key,String(value));
      }

      if(init.signal){
        if(init.signal.aborted){
          xhr.abort();
          reject(new DOMException('Abortado','AbortError'));
          return;
        }
        init.signal.addEventListener('abort',()=>xhr.abort(),{once:true});
      }

      xhr.onload=()=>{
        const responseHeaders=new Headers();
        const raw=xhr.getAllResponseHeaders().trim();
        if(raw){
          for(const line of raw.split(/[\r\n]+/)){
            const i=line.indexOf(':');
            if(i>0)responseHeaders.append(line.slice(0,i).trim(),line.slice(i+1).trim());
          }
        }
        resolve(new Response(xhr.responseText,{
          status:xhr.status,
          statusText:xhr.statusText,
          headers:responseHeaders
        }));
      };
      xhr.onerror=()=>reject(new TypeError('Falha de conexão ao salvar a personalização.'));
      xhr.ontimeout=()=>reject(new Error('A conexão demorou mais que o esperado.'));
      xhr.onabort=()=>reject(new DOMException('Abortado','AbortError'));

      xhr.send(init.body??null);
    });
  }

  function applyCurrentAppearance(body){
    const form=$('#v1224ClientAppearance');
    const selectedUnit=$('#settingsUnitSelect')?.value;

    if(!form||!selectedUnit||String(body?.p_unit_id||'')!==String(selectedUnit)){
      return body;
    }

    const settings={...(body.p_settings||{})};

    const header=$('#v1224HeaderSubtitle',form);
    const label=$('#v1224HeroLabel',form);
    const title=$('#v1224HeroTitle',form);
    const logo=$('#v1224LogoUrl',form);
    const hero=$('#v1224HeroUrl',form);

    if(header)settings.client_header_subtitle=header.value.trim();
    if(label)settings.client_hero_label=label.value.trim();
    if(title)settings.client_hero_title=title.value.trim()||'Agende seu horário.';
    if(logo)settings.client_logo_url=logo.value.trim();
    if(hero)settings.client_hero_image_url=hero.value.trim();

    body.p_settings=settings;
    return body;
  }

  window.fetch=async function(input,init={}){
    const url=typeof input==='string'?input:input?.url;

    if(typeof url!=='string'||!TARGET.test(url)||!init?.body){
      return previousFetch(input,init);
    }

    let body;
    try{
      body=typeof init.body==='string'?JSON.parse(init.body):{...(init.body||{})};
    }catch{
      return previousFetch(input,init);
    }

    const form=$('#v1224ClientAppearance');
    const selectedUnit=$('#settingsUnitSelect')?.value;

    // Fora do card de aparência, mantém exatamente o fluxo anterior.
    if(!form||!selectedUnit||String(body?.p_unit_id||'')!==String(selectedUnit)){
      return previousFetch(input,init);
    }

    body=applyCurrentAppearance(body);

    // XHR direto somente neste save: evita o interceptor antigo que recolocava
    // os valores visuais anteriores.
    const response=await xhrResponse(url,{
      ...init,
      body:JSON.stringify(body)
    });

    return response;
  };
})();
